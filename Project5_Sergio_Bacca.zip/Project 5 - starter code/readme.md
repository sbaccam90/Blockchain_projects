Token name is "starTokenRecord"
The symbol is "STR"
Truffle v5.1.11 
OpenZeppelin v2.5.0
